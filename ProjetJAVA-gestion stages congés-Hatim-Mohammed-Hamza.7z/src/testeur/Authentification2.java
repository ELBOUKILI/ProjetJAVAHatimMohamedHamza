package testeur;



import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Font;

import javax.swing.JPasswordField;





import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Authentification2 extends JFrame {

	protected static final Object PASSWORD = null;
	private JFrame frame;
	private JTextField usernamefeild;
	private JPasswordField passwordfield;
	private JPanel jpane ;
	
	Connection cnx = null ; 
	PreparedStatement prepared = null ; 
	ResultSet resultat = null ; 
	
	void fermer()
	{
		frame.dispose();
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					Authentification2 frame = new Authentification2();
					frame.frame.setVisible(true);
					frame.frame.setLocationRelativeTo(null);
					frame.frame.setTitle("Gestion des stages ");

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Authentification2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setBounds(100, 100, 1000, 500);
		frame.getContentPane().setLayout(null);
		cnx = ConnexionMysql.ConnexionDb();

		usernamefeild = new JTextField();
		usernamefeild.setBounds(399, 178, 200, 26);
		frame.getContentPane().add(usernamefeild);
		usernamefeild.setColumns(10);

		JLabel lblUserName = new JLabel("entreprise :");
		lblUserName.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblUserName.setBounds(326, 184, 74, 14);
		frame.getContentPane().add(lblUserName);

		JLabel lblPassword = new JLabel("Password  :");
		lblPassword.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblPassword.setBounds(326, 213, 74, 14);
		frame.getContentPane().add(lblPassword);

		JButton btnNewButton = new JButton("Se Connecter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			String username = usernamefeild.getText().toString();
			String password = passwordfield.getPassword().toString();
			
			String sql = "select username , PASSWORD from admin";
			
			try {
				
				prepared = cnx.prepareStatement(sql);
				resultat = prepared.executeQuery();
				int i = 0 ; 
				
				if(username.equals("") && password.equals("") )
				{
					JOptionPane.showMessageDialog(null, "Remplissez Les Champs Vides ! ");
					
				}  else
				{
					while(resultat.next())
					{
						String username1 = resultat.getString("username");
						String password1 = resultat.getString("PASSWORD");
						
						if(username1.equals(username) && !password1.equals(PASSWORD))
							JOptionPane.showMessageDialog(null," Mot de Pass Incorrect ! ");
						
						if(!username1.equals(username) && password1.equals(PASSWORD))
							JOptionPane.showMessageDialog(null, " Username Introuvable ! ");
							
						if(username1.equals(username) && password1.equals(password))
						{
							JOptionPane.showMessageDialog(null, "Connexion R�ussite :D");
							i = 1 ; 
							
							MenuAdministrateur obj = new MenuAdministrateur();
							obj.setVisible(true);
							obj.setLocationRelativeTo(null);
							
							fermer();
							
						}

						
					}
					
				}
				
				

					
				
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
				
			}
		});
		btnNewButton.setBounds(399, 243, 200, 31);
		frame.getContentPane().add(btnNewButton);

		passwordfield = new JPasswordField();
		passwordfield.setBounds(399, 206, 200, 26);
		frame.getContentPane().add(passwordfield);

	


	
	}
}
