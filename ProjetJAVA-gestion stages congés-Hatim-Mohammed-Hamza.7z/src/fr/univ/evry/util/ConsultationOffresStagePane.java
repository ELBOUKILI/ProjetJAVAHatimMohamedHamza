package fr.univ.evry.util;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import fr.univ.evry.util.actions.BackButtonListener;

public class ConsultationOffresStagePane extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8924479167507341550L;
	
	private Window window;
	
	private JLabel topLabel = new JLabel("Consultation des offres de stage");

	private JLabel nameLabel = new JLabel("Nom de l'entreprise  ");
	private JTextField nameField = new JTextField("", 15);

	private JLabel countryLabel = new JLabel("Adresse (Ville)  ");
	private JTextField countryField = new JTextField("", 15);

	private JLabel emailLabel = new JLabel("Mail de contact");
	private JTextField emailField = new JTextField("", 15);

	private JLabel domaineLabel = new JLabel("Domaine offre");
	private JTextField domaineField = new JTextField("", 15);

	private JLabel libelleLabel = new JLabel("Libell� de l'offre  ");
	private JTextField libelleField = new JTextField("", 15);

	private JLabel dateDebLabel = new JLabel("Date de d�but du stage  ");
	private JTextField dateDebField = new JTextField("", 15);

	private JLabel dureeLabel = new JLabel("Dur�e  ");
	private JTextField dureeField = new JTextField("", 15);	

	private JLabel descriptifbLabel = new JLabel("Description ");
	private JTextArea descriptifField = new JTextArea(5, 20);
	
	private JButton precedent = new JButton("Pr�c�dent");
	private JButton suivant = new JButton("Suivant");
	private JButton postuler = new JButton("postuler");
	private JButton fermer = new JButton("Fermer");   
	
	
	public ConsultationOffresStagePane(Window window) {
		this.window = window;
		this.addActionListeners();
	}
	
	public JPanel execute() {
		JPanel container = new JPanel();
		container.setLayout(new GridBagLayout());
		
		GridBagConstraints gbc = new GridBagConstraints();

		gbc.gridx = 2;
	    gbc.gridy = 0;
	    topLabel.setFont (topLabel.getFont().deriveFont (25.0f));
		container.add(topLabel, gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 1;
		container.add(nameLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 1;
		container.add(nameField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 2;
		container.add(countryLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 2;
		container.add(countryField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 3;
		container.add(emailLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 3;
		container.add(emailField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 4;
		container.add(domaineLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 4;
		container.add(domaineField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 5;
		container.add(libelleLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 5;
		container.add(libelleField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 6;
		container.add(dateDebLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 6;
		container.add(dateDebField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 7;
		container.add(dureeLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 7;
		container.add(dureeField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 8;
		container.add(descriptifbLabel, gbc);
		gbc.gridx = 3;
		gbc.gridy = 8;
		container.add(descriptifField, gbc);

		gbc.gridx = 1;
		gbc.gridy = 9;
		container.add(precedent, gbc);
		gbc.gridx = 2;
		gbc.gridy = 9;
		container.add(suivant, gbc);
		
		gbc.gridx = 3;
		gbc.gridy = 9;
		container.add(fermer, gbc);
		
		gbc.gridx =4;
		gbc.gridy = 9;
		container.add(postuler, gbc);
		
		return container;
	}
	
	public void addActionListeners() {
		fermer.addActionListener(new BackButtonListener(window, "backToHomeScreen"));
	}
}
