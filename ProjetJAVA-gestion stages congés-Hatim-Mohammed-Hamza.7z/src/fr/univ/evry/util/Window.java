package fr.univ.evry.util;

import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import fr.univ.evry.dao.EntrepriseDAO;
import fr.univ.evry.dao.StageDAO;


public class Window extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	
	
	/**
	 * Les r�f�rences des panes
	 */
	private GestionOffreStagePane gestionOffreStagePane;
	private CreationEntreprisePane creationEntreprisePane;
	private SaisieOffreStagePane saisieOffreStagePane;
	private ConsultationOffresStagePane consultationOffresStagePane;
	
	/**
	 * Les r�f�rences du DAO
	 */
	private EntrepriseDAO entrepriseDao;
	private StageDAO stageDao;
	
	public Window(EntrepriseDAO entrepriseDao, StageDAO stageDao) {
		this.initPanes();
		this.initDao(entrepriseDao, stageDao);
		
		this.setTitle("Gestion offre de stage");
		this.setSize(760, 370);
		this.setLocationRelativeTo(null);               
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.add(gestionOffreStagePane.execute());
	    
		this.setVisible(true);
	}
	
	public void performAction(String action, Object o) {
		System.out.println("[Window#performAction] triggered ! -- action : " + action);

		if (action.equals("exit")) {
			this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
		} else if (action.equals("backToHomeScreen")) {
			this.setContentPane(this.gestionOffreStagePane.execute());
			this.invalidate();
			this.validate();
		} else if (action.equals("CreateEnterpriseScreen")) {
			this.setContentPane(this.creationEntreprisePane.execute());
			this.invalidate();
			this.validate();
		} else if (action.equals("GrabOfferScreen")) {
			this.setContentPane(this.saisieOffreStagePane.execute());
			this.invalidate();
			this.validate();			
		} else if (action.equals("ConsultofferScreen")) {
			this.setContentPane(this.consultationOffresStagePane.execute());
			this.invalidate();
			this.validate();			
		} else if (action.equals("createNewEnterprise")) {
			try {
				entrepriseDao.add(o);
				JOptionPane.showMessageDialog(null, "Entreprise ajout�");
				this.setContentPane(this.gestionOffreStagePane.execute());
				this.invalidate();
				this.validate();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else if (action.equals("createNewOffer")) {
			try {
				stageDao.add(o);
				JOptionPane.showMessageDialog(null, "Offre ajout�");
				
				this.setContentPane(this.gestionOffreStagePane.execute());
				this.invalidate();
				this.validate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public void initPanes() {
		this.gestionOffreStagePane = new GestionOffreStagePane(this);
		this.creationEntreprisePane = new CreationEntreprisePane(this);
		this.saisieOffreStagePane = new SaisieOffreStagePane(this);
		this.consultationOffresStagePane = new ConsultationOffresStagePane(this);
	}
	
	public void initDao(EntrepriseDAO entrepriseDao, StageDAO stageDao) {
		this.entrepriseDao = entrepriseDao;
		this.stageDao = stageDao;
	}
	
}
