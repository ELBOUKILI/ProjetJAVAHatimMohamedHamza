package fr.univ.evry.factory;

public enum DomaineEnum {
	RESEAU,
	TRANSPORT,
	INFORMATIQUE,
	AUTRE;
}
