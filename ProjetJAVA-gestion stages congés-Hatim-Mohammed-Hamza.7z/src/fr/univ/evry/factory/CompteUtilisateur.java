package fr.univ.evry.factory;

public class CompteUtilisateur extends Compte {

	public CompteUtilisateur() {
		
	}
	
	public void postuler() {
		
	}
	
	public void seConnecter() {
		
	}
	
	public void seDeconnecter() {
		
	}
	
	public void consulter() {
		
	}
}
