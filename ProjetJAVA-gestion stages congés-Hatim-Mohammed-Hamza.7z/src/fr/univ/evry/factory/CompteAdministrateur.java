package fr.univ.evry.factory;

public class CompteAdministrateur extends Compte {

	
	public CompteAdministrateur() {
		
	}
	
	public void seConnecter() {
		
	}
	
	public void seDeconnecter() {
		
	}
	
	public void supprOffre() {
		
	}
	
	public void consulter(Offre offre) {
		
	}
	
	public void add(Offre offre) {
		
	}
	
	public void add(Entreprise entreprise) {
		
	}
	
	public void consulter(String postulant, Offre offre) {
		
	}
	
	public void creerEntreprise(String nom) {
		
	}
	
	public void creerOffre(String libelle, String descriptif) {
		
	}
	
}
