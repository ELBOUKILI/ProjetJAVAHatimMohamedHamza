package fr.univ.evry.factory;

public class Offre {

	private String libelle;
	private String descriptif;
	private String domaine;
	private String dateDebut;
	private String duree;
	private String chemin;
	private String valide;
	
	
	public Offre(String libelle, String descriptif, String domaine, String dateDebut, String duree, String chemin, String valide) {
		this.libelle = libelle;
		this.descriptif = descriptif;
		this.domaine = domaine;
		this.dateDebut = dateDebut;
		this.duree = duree;
		this.chemin = chemin;
		this.valide = valide;
	}


	public String getLibelle() {
		return libelle;
	}


	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}


	public String getDescriptif() {
		return descriptif;
	}


	public void setDescriptif(String descriptif) {
		this.descriptif = descriptif;
	}


	public String getDomaine() {
		return domaine;
	}


	public void setDomaine(String domaine) {
		this.domaine = domaine;
	}


	public String getDateDebut() {
		return dateDebut;
	}


	public void setDateDebut(String dateDebut) {
		this.dateDebut = dateDebut;
	}


	public String getDuree() {
		return duree;
	}


	public void setDuree(String duree) {
		this.duree = duree;
	}


	public String getChemin() {
		return chemin;
	}


	public void setChemin(String chemin) {
		this.chemin = chemin;
	}


	public String getValide() {
		return valide;
	}


	public void setValide(String valide) {
		this.valide = valide;
	}
}
