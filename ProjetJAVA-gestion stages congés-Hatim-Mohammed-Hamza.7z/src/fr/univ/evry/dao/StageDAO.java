package fr.univ.evry.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import fr.univ.evry.database.util.DBConnect;
import fr.univ.evry.factory.Offre;

public class StageDAO implements DAOUtil {
	private DBConnect dbConnect;
	
	public StageDAO(DBConnect dbConnect) {
		this.dbConnect = dbConnect;
	}
	
	@Override
	public void add(Object o) throws SQLException {
		Connection connect= dbConnect.getConnection();
		System.out.println("[StageDAO#add] object : " + o);
		
		PreparedStatement preparedStatement = connect.prepareStatement("INSERT INTO stage VALUES (null, ?, ?, ?, ?, ?, ?, 1)");

		preparedStatement.setString(1, ((Offre) o).getDomaine());
		preparedStatement.setString(2, ((Offre) o).getLibelle());
		preparedStatement.setString(3, ((Offre) o).getDateDebut());
		preparedStatement.setString(4, ((Offre) o).getDuree());
		preparedStatement.setString(5, ((Offre) o).getChemin());
		preparedStatement.setString(6, ((Offre) o).getDescriptif());
		
		preparedStatement.executeUpdate();
	}

	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object find(Object o) {
		// TODO Auto-generated method stub
		return null;
	}

}
