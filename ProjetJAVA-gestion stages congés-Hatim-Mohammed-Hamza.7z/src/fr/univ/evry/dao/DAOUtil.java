package fr.univ.evry.dao;

import java.sql.SQLException;

public interface DAOUtil {

	public void add(Object o) throws SQLException;
	public boolean remove(Object o);
	public Object find(Object o);
	
}
